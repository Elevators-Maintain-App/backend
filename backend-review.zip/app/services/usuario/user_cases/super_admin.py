from fastapi import HTTPException
from app.db.models.compania import Compania
from app.db.models import TipoDocumento
from app.db.models.usuarios import Usuario, Rol
from app.schemas.usuarios import UsuarioCreate
from app.auth.firebase import FirebaseUser
from app.services.usuario.interfaces import UsuarioCaseInterface, CrearUsuarioFirebaseParams, CrearUsuarioParams
from typing import Optional
from uuid import UUID
from .base_usuario import BaseUsuario
from app.db.models.clientes import Cliente

VERTIONE_COMPANY_ID = "00000000-0000-0000-0000-000000000000"
VERTIONE_NAME = "VertiOne"


class SuperAdminCase(BaseUsuario):
    def obtener_firebase_usuario(self, params: CrearUsuarioFirebaseParams) -> FirebaseUser:
        usuario_actual: Usuario = params.usuario_actual
        usuario_nuevo: UsuarioCreate = params.usuario_nuevo
        compania: Compania = params.compania
        tipo_documento: TipoDocumento = params.tipo_documento
        cliente: Cliente | None = params.cliente
        
        if usuario_actual.rol not in [Rol.SUPER_ADMIN]:
            raise HTTPException(status_code=403, detail="No tienes permisos para crear usuarios")
            
        return self.mapear_usuario_dto_a_usuario_firebase(usuario_nuevo, compania, tipo_documento, cliente) 

    def validar_y_normalizar_company_id(self, usuario_actual: Usuario, company_id: Optional[UUID]) -> UUID:
        """
        Valida y normaliza el company_id para superAdmin.
        Requiere que se proporcione company_id.
        """
        if usuario_actual.rol not in [Rol.SUPER_ADMIN]:
            raise HTTPException(status_code=403, detail="No tienes permisos para crear usuarios")
        
        if company_id is None:
            raise HTTPException(
                status_code=400,
                detail="El company_id es requerido"
            )
        
        return company_id

    def obtener_usuario_a_guardar(self, params: CrearUsuarioParams) -> Usuario:
        usuario_actual: Usuario = params.usuario_actual
        usuario_nuevo: UsuarioCreate = params.usuario_nuevo
        firebase_uid: str = params.firebase_uid

        if usuario_actual.rol not in [Rol.SUPER_ADMIN]:
            raise HTTPException(status_code=403, detail="No tienes permisos para crear usuarios")

        usuario = self.mapear_usuario_dto_a_usuario_create(usuario_nuevo, firebase_uid)

        return usuario
        
    def obtener_filtros_para_listar_usuarios(self, usuario_actual: Usuario, search: Optional[str], company_id: Optional[str], rol: Optional[str]) -> dict:        
        filters = {
            "exact_filters": {},
            "ilike_filters": {},
            "like_filters": {}
        }
        
        if search:
            filters["ilike_filters"]["display_name"] = f"%{search}%"
        if company_id:
            filters["exact_filters"]["company_id"] = company_id
        if rol:
            filters["exact_filters"]["rol"] = rol
            
        return filters
    
    def obtener_filtro_para_totalizar_usuarios(self, usuario_actual: Usuario, company_id: Optional[UUID], rol: Optional[Rol]) -> dict:        
        filters = {
            "exact_filters": {
            },
            "ilike_filters": {},
            "like_filters": {}
        }
        if company_id:
            filters["exact_filters"]["company_id"] = company_id
        if rol:
            filters["exact_filters"]["rol"] = rol

        return filters


    
