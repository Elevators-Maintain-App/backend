from typing import Any, Dict, Generic, List, Optional, Type, TypeVar, Union
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import update as sql_update, delete as sql_delete
from pydantic import BaseModel
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session, selectinload
from fastapi import HTTPException
from app.db.session import Base
from sqlalchemy import func

ModelType = TypeVar("ModelType", bound=Base)
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)

class BaseRepository(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    def __init__(self, model: Type[ModelType], db: AsyncSession):
        self.model = model
        self.db = db

    async def get(self, id: Any) -> Optional[ModelType]:
        """
        Get a single record by ID
        """
        query = select(self.model).where(self.model.id == id)
        result = await self.db.execute(query)
        return result.scalars().first()

    async def get_by_field(self, field: str, value: Any) -> Optional[ModelType]:
        """
        Get a single record by a specific field value
        """
        query = select(self.model).where(getattr(self.model, field) == value)
        result = await self.db.execute(query)
        return result.scalars().first()

    async def list(self, *, skip: int = 0, limit: int = 100) -> List[ModelType]:
        """
        Get multiple records with pagination
        """
        query = select(self.model).offset(skip).limit(limit)
        result = await self.db.execute(query)
        return result.scalars().all()

    async def create(self, *, obj_in: CreateSchemaType) -> ModelType:
        """
        Create a new record
        """
        obj_in_data = jsonable_encoder(obj_in)
        db_obj = self.model(**obj_in_data)
        self.db.add(db_obj)
        await self.db.commit()
        await self.db.refresh(db_obj)
        return db_obj

    async def update(
        self, *, db_obj: ModelType, obj_in: Union[UpdateSchemaType, Dict[str, Any]]
    ) -> ModelType:
        """
        Update a record
        """
        obj_data = jsonable_encoder(db_obj)
        
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.model_dump(exclude_unset=True)
            
        for field in obj_data:
            if field in update_data:
                setattr(db_obj, field, update_data[field])
                
        self.db.add(db_obj)
        await self.db.commit()
        await self.db.refresh(db_obj)
        return db_obj

    async def delete(self, *, id: Any) -> ModelType:
        """
        Delete a record by ID
        """
        obj = await self.get(id)
        if obj:
            await self.db.delete(obj)
            await self.db.commit()
        return obj 
    
class CRUDBaseRepository(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    def __init__(self, model: Type[ModelType]):
        self.model = model

    async def get(self, db: AsyncSession, id: Any) -> Optional[ModelType]:
        result = await db.execute(select(self.model).where(self.model.id == id))
        return result.scalars().first()

    async def get_multi(self, db: AsyncSession, skip: int = 0, limit: int = 100, filters: dict = None) -> List[ModelType]:
        query = select(self.model).offset(skip).limit(limit)
        if filters:
            for field, value in filters.items():
                query = query.where(getattr(self.model, field) == value)
        result = await db.execute(query)
        return result.scalars().all()

    async def get_multi_with_advanced_filters(self, db: AsyncSession, skip: int = 0, limit: int = 100, exact_filters: dict = None, ilike_filters: dict = None, like_filters: dict = None) -> List[ModelType]:
        query = select(self.model).offset(skip).limit(limit)
        if exact_filters:
            for field, value in exact_filters.items():
                query = query.where(getattr(self.model, field) == value)
        if ilike_filters:
            for field, value in ilike_filters.items():
                query = query.where(getattr(self.model, field).ilike(value))
        if like_filters:
            for field, value in like_filters.items():
                query = query.where(getattr(self.model, field).like(value))
        result = await db.execute(query)

        return result.scalars().all()
    
    async def get_total_with_advanced_filters(self, db: AsyncSession, exact_filters: dict = None, ilike_filters: dict = None, like_filters: dict = None) -> int:
        query = select(func.count()).select_from(self.model)
        if exact_filters:
            for field, value in exact_filters.items():
                query = query.where(getattr(self.model, field) == value)
        if ilike_filters:
            for field, value in ilike_filters.items():
                query = query.where(getattr(self.model, field).ilike(value))
        if like_filters:
            for field, value in like_filters.items():
                query = query.where(getattr(self.model, field).like(value))
        result = await db.execute(query)
        return result.scalar()

    async def get_total_by_field(self, db: AsyncSession, field: str, value: Any) -> int:
        query = select(func.count()).where(getattr(self.model, field) == value)
        result = await db.execute(query)
        return result.scalar()

    async def create(self, db: AsyncSession, obj_in: CreateSchemaType) -> ModelType:
        try:            
            obj_in_data = obj_in.model_dump(exclude_unset=True)
            db_obj = self.model(**obj_in_data)
            db.add(db_obj)
            await db.commit()
            await db.refresh(db_obj)
            return db_obj
        except Exception as e:
            print("**** error al crear la entidad", e)
            raise HTTPException(status_code=500, detail=f"Error al crear {self.model.__name__}")


    async def update(self, db: AsyncSession, db_obj: ModelType, obj_in: Union[UpdateSchemaType, Dict[str, Any]]) -> ModelType:
        obj_data = jsonable_encoder(db_obj)
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.model_dump(exclude_unset=True)

        for field in obj_data:
            if field in update_data:
                setattr(db_obj, field, update_data[field])

        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def remove(self, db: AsyncSession, id: Any) -> Optional[ModelType]:
        obj = await self.get(db, id)
        if obj:
            await db.delete(obj)
            await db.commit()
        return obj
    
    async def get_by_field(self, db: AsyncSession, field: str, value: Any) -> Optional[ModelType]:
        stmt = select(self.model).where(getattr(self.model, field) == value)
        result = await db.execute(stmt)
        return result.scalars().first()
    
    async def get_multi_by_field(self, db: AsyncSession, field: str, value: Any) -> List[ModelType]:
        """
        Devuelve todos los registros que coincidan con un valor específico en un campo.
        """
        stmt = select(self.model).where(getattr(self.model, field) == value)
        result = await db.execute(stmt)
        return result.scalars().all()

    async def get_multi_by_field(
        self,
        db: AsyncSession,
        field: str,
        value: Any,
        skip: int = 0,
        limit: int = 100
    ) -> List[ModelType]:
        stmt = select(self.model).where(getattr(self.model, field) == value).offset(skip).limit(limit)
        result = await db.execute(stmt)
        return result.scalars().all()
    
    async def get_multi_by_filters(
        self,
        db: AsyncSession,
        filters: List[Any],
        skip: int = 0,
        limit: int = 100
    ) -> List[ModelType]:
        """
        Devuelve todos los registros que cumplan todas las condiciones de `filters`.
        Cada elemento de `filters` es un criterio SQLAlchemy (e.g. Model.field == value).
        """
        stmt = select(self.model).where(*filters).offset(skip).limit(limit)
        result = await db.execute(stmt)
        return result.scalars().all()