from pydantic import BaseModel, UUID4
from typing import Optional

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    
class TokenPayload(BaseModel):
    sub: Optional[str] = None
    user_id: Optional[UUID4] = None
    exp: Optional[int] = None 