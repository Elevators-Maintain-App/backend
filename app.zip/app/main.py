from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import (
    clientes_router,
    tipos_documento_router,
    estados_orden_router,
    prioridades_router,
    tipos_evidencia_router,
    tipos_orden_router,
    tipos_unidad_router,
    proyectos_router,
    supervisores_router,
    tecnicos_router,
    ordenes_trabajo_router,
    checklists_router,
    unidades_router,
    admin_dashboard,
    dashboard,
    hojas_de_vida,
    zonas_geograficas
)
from app.core.config import settings
from app.db.session import engine, Base

# Lifespan context manager for startup and shutdown events
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Create database tables
    async with engine.begin() as conn:
        # In production, use Alembic for migrations instead
        if settings.environment == "development":
            await conn.run_sync(Base.metadata.create_all)
    
    print("Application startup complete")
    yield
    # Shutdown: Cleanup resources
    print("Application shutdown complete")

# Create FastAPI application
app = FastAPI(
    title=settings.app_name,
    description="FastAPI application with layered architecture",
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    debug=settings.debug
)

# Setup CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", tags=["health"])
async def health_check():
    """Health check endpoint"""
    return {"status": "Ok", "message": "API is running"}

# Register API routes
app.include_router(clientes_router, prefix="/api/clientes", tags=["Clientes"])
app.include_router(proyectos_router, prefix="/api/proyectos", tags=["Proyectos"])
app.include_router(supervisores_router, prefix="/api/supervisores", tags=["Supervisores"])
app.include_router(tecnicos_router, prefix="/api/tecnicos", tags=["Técnicos"])
app.include_router(ordenes_trabajo_router, prefix="/api/ordenes-trabajo", tags=["Ordenes de Trabajo"])
app.include_router(checklists_router, prefix="/api/checklists", tags=["Checklists"])
app.include_router(unidades_router, prefix="/api/unidades", tags=["Unidades"])
app.include_router(admin_dashboard, prefix="/api/dashboard", tags=["Admin Dashboard"])
app.include_router(dashboard, prefix="/api/dashboard", tags=["Dashboard"])
app.include_router(hojas_de_vida, prefix="/api/hojas-vida", tags=["Hojas de Vida"])
app.include_router(zonas_geograficas, prefix="/api/zonas-geograficas", tags=["Zonas Geograficas"])
app.include_router(tipos_documento_router, prefix="/api/tipos-documento", tags=["Enums"])
app.include_router(estados_orden_router, prefix="/api/estados-orden", tags=["Enums"])
app.include_router(prioridades_router, prefix="/api/prioridades", tags=["Enums"])
app.include_router(tipos_evidencia_router, prefix="/api/tipos-evidencia", tags=["Enums"])
app.include_router(tipos_orden_router, prefix="/api/tipos-orden", tags=["Enums"])
app.include_router(tipos_unidad_router, prefix="/api/tipos-unidad", tags=["Enums"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host=settings.host, port=settings.port, reload=True) 